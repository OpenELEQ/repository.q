1) Copy script.widget.info folder to Kodi addons folder
2) Copy keymap.xml file to userdata\keymaps\ or add the entries to your existing keymap file
3) Restart Kodi
4) Thank Mr. V ;-)
5) Enjoy your new widgets!